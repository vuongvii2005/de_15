package com.mycompany.mainframe;

import java.util.ArrayList;
import java.util.HashMap;

public class SinhVien {
    private String maSV;
    private String tenSV;
    private String ngaySinh; // Thêm trường ngày sinh
    private String lop;
    private String khoiThi;
    private HashMap<String, Double> diemThi; // Lưu điểm theo môn
    private ArrayList<String> monThi; // Lưu các môn thi

    public SinhVien(String maSV, String tenSV, String ngaySinh, String lop, String khoiThi, ArrayList<String> monThi) {
        this.maSV = maSV;
        this.tenSV = tenSV;
        this.ngaySinh = ngaySinh; // Khởi tạo ngày sinh
        this.lop = lop;
        this.khoiThi = khoiThi;
        this.monThi = monThi;
        this.diemThi = new HashMap<>(); // Khởi tạo HashMap để lưu điểm
    }

    // Getter và Setter
    public String getMaSV() { return maSV; }
    public String getTenSV() { return tenSV; }
    public String getNgaySinh() { return ngaySinh; } // Thêm getter cho ngày sinh
    public String getLop() { return lop; }
    public String getKhoiThi() { return khoiThi; }
    public ArrayList<String> getMonThi() { return monThi; }

    public void setMaSV(String maSV) {
        this.maSV = maSV;
    }

    public void setTenSV(String tenSV) {
        this.tenSV = tenSV;
    }

    public void setNgaySinh(String ngaySinh) { // Thêm setter cho ngày sinh
        this.ngaySinh = ngaySinh;
    }

    public void setLop(String lop) {
        this.lop = lop;
    }

    public void setKhoiThi(String khoiThi) {
        this.khoiThi = khoiThi;
    }

    public void themDiemThi(String mon, double diem) {
        diemThi.put(mon, diem); // Thêm điểm cho môn
    }

    public String hienThiDiemThi() {
        StringBuilder sb = new StringBuilder();
        for (String mon : monThi) {
            Double diem = diemThi.get(mon);
            if (diem != null) {
                sb.append(mon).append(": ").append(diem).append("   "); // Cách nhau bằng 3 khoảng trắng
            } else {
                sb.append(mon).append(": Chưa có điểm   "); // Nếu chưa có điểm
            }
        }
        return sb.toString();
    }

    public double tinhTongDiem() {
        double tongDiem = 0;
        for (Double diem : diemThi.values()) {
            tongDiem += diem;
        }
        return tongDiem; // Trả về tổng điểm
    }

    // Phương thức để hiển thị thông tin sinh viên
    @Override
    public String toString() {
        return maSV + " - " + tenSV + " - " + ngaySinh + " - " + lop; // Cập nhật hiển thị thông tin
    }
}