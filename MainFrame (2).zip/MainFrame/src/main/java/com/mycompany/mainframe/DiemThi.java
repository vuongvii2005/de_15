/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.mainframe;

/**
 *
 * @author ADMIN
 */
public class DiemThi {
    private String maSV;
    private String maMH;
    private float diem;

    public DiemThi(String maSV, String maMH, float diem) {
        this.maSV = maSV;
        this.maMH = maMH;
        this.diem = diem;
    }

    // Getter và Setter
    public String getMaSV() { return maSV; }
    public String getMaMH() { return maMH; }
    public float getDiem() { return diem; }
}
