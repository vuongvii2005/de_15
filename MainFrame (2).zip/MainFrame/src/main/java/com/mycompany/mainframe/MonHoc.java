/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.mainframe;

/**
 *
 * @author ADMIN
 */
public class MonHoc {
    private String maMH;
    private String tenMH;
    private int soTinChi;

    public MonHoc(String maMH, String tenMH, int soTinChi) {
        this.maMH = maMH;
        this.tenMH = tenMH;
        this.soTinChi = soTinChi;
    }

    // Getter và Setter
    public String getMaMH() { return maMH; }
    public String getTenMH() { return tenMH; }
    public int getSoTinChi() { return soTinChi; }
}