package com.mycompany.mainframe;

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.ArrayList;

public class MainFrame extends JFrame {
    private JTextField txtMaSV, txtTenSV, txtLop, txtKhoiThi, txtNgaySinh; // Thêm trường ngày sinh
    private JButton btnThemSV, btnXoaSV, btnSuaSV, btnTimSV, btnThongKe;
    private JTable tableSV;
    private ArrayList<SinhVien> danhSachSV; // Danh sách sinh viên

    public MainFrame() {
        setTitle("Quản Lý Điểm Thi Đại Học");
        setSize(800, 400);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setLocationRelativeTo(null);

        danhSachSV = new ArrayList<>(); // Khởi tạo danh sách sinh viên

        // Tạo panel cho sinh viên với GridBagLayout
        JPanel panelSV = new JPanel(new GridBagLayout());
        GridBagConstraints gbc = new GridBagConstraints();
        gbc.insets = new Insets(2, 2, 2, 2); // Điều chỉnh khoảng cách giữa các thành phần

        gbc.gridx = 0; gbc.gridy = 0;
        gbc.anchor = GridBagConstraints.LINE_END;
        panelSV.add(new JLabel("Mã SV:"), gbc);

        gbc.gridx = 1; gbc.gridy = 0;
        gbc.anchor = GridBagConstraints.LINE_START;
        txtMaSV = new JTextField(20);
        panelSV.add(txtMaSV, gbc);

        gbc.gridx = 0; gbc.gridy = 1;
        gbc.anchor = GridBagConstraints.LINE_END;
        panelSV.add(new JLabel("Tên SV:"), gbc);

        gbc.gridx = 1; gbc.gridy = 1;
        gbc.anchor = GridBagConstraints.LINE_START;
        txtTenSV = new JTextField(20);
        panelSV.add(txtTenSV, gbc);

        gbc.gridx = 0; gbc.gridy = 2;
        gbc.anchor = GridBagConstraints.LINE_END;
        panelSV.add(new JLabel("Ngày Sinh:"), gbc); // Thêm nhãn ngày sinh

        gbc.gridx = 1; gbc.gridy = 2;
        gbc.anchor = GridBagConstraints.LINE_START;
        txtNgaySinh = new JTextField(20); // Thêm trường nhập ngày sinh
        panelSV.add(txtNgaySinh, gbc);

        gbc.gridx = 0; gbc.gridy = 3;
        gbc.anchor = GridBagConstraints.LINE_END;
        panelSV.add(new JLabel("Lớp:"), gbc);

        gbc.gridx = 1; gbc.gridy = 3;
        gbc.anchor = GridBagConstraints.LINE_START;
        txtLop = new JTextField(20);
        panelSV.add(txtLop, gbc);

        gbc.gridx = 0; gbc.gridy = 4;
        gbc.anchor = GridBagConstraints.LINE_END;
        panelSV.add(new JLabel("Khối Thi:"), gbc);

        gbc.gridx = 1; gbc.gridy = 4;
        gbc.anchor = GridBagConstraints.LINE_START;
        txtKhoiThi = new JTextField(20);
        panelSV.add(txtKhoiThi, gbc);

        gbc.gridx = 0; gbc.gridy = 5;
        gbc.gridwidth = 2;
        gbc.anchor = GridBagConstraints.CENTER;

        // Tạo panel cho nút
        JPanel panelButtons = new JPanel(new FlowLayout());
        btnThemSV = new JButton("Thêm Sinh Viên");
btnXoaSV = new JButton("Xóa Sinh Viên");
        btnSuaSV = new JButton("Sửa Sinh Viên");
        btnTimSV = new JButton("Tìm Sinh Viên");
        btnThongKe = new JButton("Thống Kê");

        // Thêm các nút vào panel
        panelButtons.add(btnThemSV);
        panelButtons.add(btnXoaSV);
        panelButtons.add(btnSuaSV);
        panelButtons.add(btnTimSV);
        panelButtons.add(btnThongKe);

        panelSV.add(panelButtons, gbc); // Thêm panel nút vào panelSV

        // Tạo bảng để hiển thị danh sách sinh viên
        String[] columnNames = {"STT", "Mã SV", "Tên SV", "Ngày Sinh", "Lớp", "Khối Thi", "Môn Thi", "Điểm Thi", "Tổng Điểm"};
        tableSV = new JTable(new Object[][]{}, columnNames);
        JScrollPane scrollPane = new JScrollPane(tableSV);

        // Thêm các thành phần vào JFrame
        setLayout(new BorderLayout());
        add(panelSV, BorderLayout.NORTH);
        add(scrollPane, BorderLayout.CENTER);

        // Thêm sự kiện cho nút "Thêm Sinh Viên"
        btnThemSV.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                themSinhVien();
            }
        });

        // Thêm sự kiện cho nút "Xóa Sinh Viên"
        btnXoaSV.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                xoaSinhVien();
            }
        });

        // Thêm sự kiện cho nút "Sửa Sinh Viên"
        btnSuaSV.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                suaSinhVien();
            }
        });

        // Thêm sự kiện cho nút "Tìm Sinh Viên"
        btnTimSV.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                timSinhVien();
            }
        });

        // Thêm sự kiện cho nút "Thống Kê"
        btnThongKe.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                thongKe();
            }
        });

        setVisible(true);
    }

    private void themSinhVien() {
        String maSV = txtMaSV.getText();
        String tenSV = txtTenSV.getText();
        String ngaySinh = txtNgaySinh.getText(); // Lấy ngày sinh từ trường nhập
        String lop = txtLop.getText();
        String khoiThi = txtKhoiThi.getText();

        ArrayList<String> monThi = new ArrayList<>();
        switch (khoiThi.toUpperCase()) {
            case "A":
                monThi.add("Toán");
                monThi.add("Lý");
                monThi.add("Hóa");
                break;
            case "A1":
                monThi.add("Toán");
                monThi.add("Lý");
                monThi.add("Anh");
                break;
case "B":
                monThi.add("Toán");
                monThi.add("Sinh");
                monThi.add("Hóa");
                break;
            case "C":
                monThi.add("Văn");
                monThi.add("Sử");
                monThi.add("Địa");
                break;
            case "D":
                monThi.add("Toán");
                monThi.add("Văn");
                monThi.add("Anh");
                break;
            default:
                JOptionPane.showMessageDialog(this, "Khối thi không hợp lệ!");
                return;
        }

        // Thêm sinh viên vào danh sách
        SinhVien sv = new SinhVien(maSV, tenSV, ngaySinh, lop, khoiThi, monThi);
        danhSachSV.add(sv); // Thêm sinh viên vào danh sách

        // Nhập điểm cho sinh viên vừa thêm
        nhapDiemChoSinhVien(sv);

        // Cập nhật bảng
        updateTable();

        // Thông báo thêm sinh viên thành công
        JOptionPane.showMessageDialog(this, "Thêm sinh viên thành công!");

        // Reset các trường nhập
        resetInputFields();
    }

    private void xoaSinhVien() {
        String maSV = JOptionPane.showInputDialog(this, "Nhập mã sinh viên cần xóa:");
        if (maSV != null && !maSV.trim().isEmpty()) {
            boolean found = false;
            for (SinhVien sv : danhSachSV) {
                if (sv.getMaSV().equals(maSV)) {
                    danhSachSV.remove(sv);
                    found = true;
                    break;
                }
            }
            if (found) {
                updateTable();
                JOptionPane.showMessageDialog(this, "Xóa sinh viên thành công!");
            } else {
                JOptionPane.showMessageDialog(this, "Không tìm thấy sinh viên với mã: " + maSV);
            }
        }
    }

    private void suaSinhVien() {
        String maSV = JOptionPane.showInputDialog(this, "Nhập mã sinh viên cần sửa:");
        if (maSV != null && !maSV.trim().isEmpty()) {
            for (SinhVien sv : danhSachSV) {
                if (sv.getMaSV().equals(maSV)) {
                    String tenSV = JOptionPane.showInputDialog(this, "Nhập tên sinh viên mới:", sv.getTenSV());
                    String ngaySinh = JOptionPane.showInputDialog(this, "Nhập ngày sinh mới:", sv.getNgaySinh());
                    String lop = JOptionPane.showInputDialog(this, "Nhập lớp mới:", sv.getLop());
                    String khoiThi = JOptionPane.showInputDialog(this, "Nhập khối thi mới:", sv.getKhoiThi());

                    // Cập nhật thông tin sinh viên
                    sv.setTenSV(tenSV);
                    sv.setNgaySinh(ngaySinh); // Cập nhật ngày sinh
                    sv.setLop(lop);
                    sv.setKhoiThi(khoiThi);

                    // Cập nhật bảng
                    updateTable();
// Thông báo sửa sinh viên thành công
                    JOptionPane.showMessageDialog(this, "Sửa thông tin sinh viên thành công!");
                    return;
                }
            }
            JOptionPane.showMessageDialog(this, "Không tìm thấy sinh viên với mã: " + maSV);
        }
    }

    private void timSinhVien() {
        String maSV = JOptionPane.showInputDialog(this, "Nhập mã sinh viên cần tìm:");
        if (maSV != null && !maSV.trim().isEmpty()) {
            for (SinhVien sv : danhSachSV) {
                if (sv.getMaSV().equals(maSV)) {
                    JOptionPane.showMessageDialog(this, "Thông tin sinh viên: " + sv.toString() + "\n" + sv.hienThiDiemThi());
                    return;
                }
            }
            JOptionPane.showMessageDialog(this, "Không tìm thấy sinh viên với mã: " + maSV);
        }
    }

    private void thongKe() {
        StringBuilder sb = new StringBuilder();
        for (SinhVien sv : danhSachSV) {
            sb.append(sv.getMaSV()).append(" - ").append(sv.getTenSV()).append(" - Tổng điểm: ").append(sv.tinhTongDiem()).append("\n");
        }
        JOptionPane.showMessageDialog(this, sb.toString());
    }

    private void resetInputFields() {
        txtMaSV.setText("");
        txtTenSV.setText("");
        txtNgaySinh.setText(""); // Reset ngày sinh
        txtLop.setText("");
        txtKhoiThi.setText("");
    }

    private void nhapDiemChoSinhVien(SinhVien sv) {
        for (String mon : sv.getMonThi()) {
            boolean validInput = false;
            while (!validInput) {
                String diem = JOptionPane.showInputDialog(this, "Nhập điểm cho môn " + mon + " của sinh viên " + sv.getTenSV() + ":");
                if (diem != null) {
                    try {
                        double diemValue = Double.parseDouble(diem);
                        if (diemValue < 0 || diemValue > 10) {
                            JOptionPane.showMessageDialog(this, "Điểm phải từ 0 đến 10! Vui lòng nhập lại.");
                        } else {
                            sv.themDiemThi(mon, diemValue);
                            validInput = true;
                        }
                    } catch (NumberFormatException e) {
                        JOptionPane.showMessageDialog(this, "Điểm phải là một số! Vui lòng nhập lại.");
                    }
                } else {
                    validInput = true;
                }
            }
        }
        updateTable(); // Cập nhật bảng sau khi nhập điểm
    }

    private void updateTable() {
        String[][] data = new String[danhSachSV.size()][9]; // Thay đổi kích thước cho 9 cột
        for (int i = 0; i < danhSachSV.size(); i++) {
            SinhVien sv = danhSachSV.get(i);
            data[i][0] = String.valueOf(i + 1); // STT
            data[i][1] = sv.getMaSV();
data[i][2] = sv.getTenSV();
            data[i][3] = sv.getNgaySinh(); // Hiển thị ngày sinh
            data[i][4] = sv.getLop();
            data[i][5] = sv.getKhoiThi();
            data[i][6] = String.join(", ", sv.getMonThi()); // Hiển thị các môn thi
            data[i][7] = sv.hienThiDiemThi(); // Hiển thị điểm thi
            data[i][8] = String.valueOf(sv.tinhTongDiem()); // Hiển thị tổng điểm
        }

        tableSV.setModel(new javax.swing.table.DefaultTableModel(data, new String[]{"STT", "Mã SV", "Tên SV", "Ngày Sinh", "Lớp", "Khối Thi", "Môn Thi", "Điểm Thi", "Tổng Điểm"}));
    }

    public static void main(String[] args) {
        new LoginFrame(); // Bắt đầu với trang đăng nhập
    }
}