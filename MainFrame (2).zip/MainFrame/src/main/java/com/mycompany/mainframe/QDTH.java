/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.mainframe;

/**
 *
 * @author ADMIN
 */
import java.util.ArrayList;

public class QDTH {
    private ArrayList<SinhVien> danhSachSV;
    private ArrayList<MonHoc> danhSachMH;
    private ArrayList<DiemThi> danhSachDiem;

    public QDTH() {
        danhSachSV = new ArrayList<>();
        danhSachMH = new ArrayList<>();
        danhSachDiem = new ArrayList<>();
    }

    // Các phương thức để quản lý sinh viên, môn học và điểm thi
    public void themSinhVien(SinhVien sv) {
        danhSachSV.add(sv);
    }

    public void themMonHoc(MonHoc mh) {
        danhSachMH.add(mh);
    }

    public void nhapDiem(DiemThi diem) {
        danhSachDiem.add(diem);
    }
    public ArrayList<SinhVien> getDanhSachSV() {
        return danhSachSV;
    }
    public ArrayList<MonHoc> getDanhSachMH() {
    return danhSachMH;
}

    public ArrayList<DiemThi> getDanhSachDiem() {
        return danhSachDiem;
    }
}

