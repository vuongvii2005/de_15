/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package app;

//import PieChart_AWT;
import controllers.LogInController;
import controllers.QuanLyDiemController;
import controllers.ThiSinhController;
import controllers.ThongKeController;
import utilities.ui.*;
//import controlller.TabPanel;
import java.util.Map;
import javax.swing.JComponent;
import javax.swing.JPanel;
import javax.swing.JTabbedPane;
import javax.swing.WindowConstants;
import views.QuanLyDiemView;
import views.ThiSinhView;
import views.ThongKeView;

public interface Controllers {
    // Bản đồ lưu trữ các panel (controller) với tên panel tương ứng
    static Map<String, Controller> panels = Map.ofEntries(
            // Tạo mục nhập cho panel đăng nhập với tên "dangNhap"
            Map.entry("dangNhap", new LogInController()),
            // Tạo mục nhập cho panel chính với tên "mainView"
            Map.entry("mainView", new TabPanel(JTabbedPane.TOP, Map.ofEntries(
                    // Các tab trong mainView
                    Map.entry("1. Quản lý điểm", new QuanLyDiemController()), // Tab Quản lý điểm
                    Map.entry("2. Thí sinh", new ThiSinhController()), // Tab Thí sinh
                    Map.entry("3. Thống kê", new ThongKeController()) // Tab Thống kê
            )))
    );

    // Đối tượng chính chứa các panel, cấu hình thoát khi đóng cửa sổ
    static ContainerFrame views = new ContainerFrame(WindowConstants.EXIT_ON_CLOSE, panels);

    // Phương thức để chuyển đổi giữa các panel
    public static void ChangePanel(String name) {
        // Gọi phương thức changePanel từ ContainerFrame để chuyển sang panel có tên tương ứng
        views.changePanel(name);
    }
}

