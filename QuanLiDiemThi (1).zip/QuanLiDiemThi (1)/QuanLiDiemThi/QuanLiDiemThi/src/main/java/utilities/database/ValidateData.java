/*
 * Interface ValidateData cung cấp các phương thức tĩnh để kiểm tra tính hợp lệ của các loại dữ liệu đầu vào khác nhau.
 */
package utilities.database;

// tóm lại file này là file kiểm tra tính đúng sai

import java.util.Date;
import java.util.GregorianCalendar;

public interface ValidateData {
    
    //Kiểm tra xem một chuỗi có thể được coi là một số nguyên dương hay không.
    //@param x chuỗi cần kiểm tra
    //@return true nếu chuỗi không rỗng và chỉ chứa các chữ số, false trong các trường hợp khác
     
    static boolean validateInt(String x) {
        try {
            if (x.length() == 0) return false;
            return x.chars().allMatch(Character::isDigit);
        } catch (NumberFormatException e) {
            return false;
        }
    }

    
    //Kiểm tra xem một chuỗi chỉ chứa các ký tự chữ cái.
    //@param x chuỗi cần kiểm tra
    //@return true nếu chuỗi không rỗng và không chứa chữ số, false trong các trường hợp khác
     
    static boolean validateStr(String x) {
        if (x.length() == 0) return false;
        return !x.chars().anyMatch(Character::isDigit);
    }

    
    //Kiểm tra xem một ngày có nằm trong khoảng thời gian cho phép hay không.
    //@param d ngày cần kiểm tra
    //@return true nếu ngày không null, nằm sau ngày 1 tháng 1 năm 1900 và trước hoặc bằng ngày hiện tại
    
    static boolean validateDate(Date d) {
        if (d == null) return false;
        Date now = new Date();
        Date past = new GregorianCalendar(1900, 0, 1).getTime();
        return d.after(past) && (d.before(now) || d.equals(now));
    }

    
    //Kiểm tra xem một chuỗi có đại diện cho điểm trong khoảng từ 0 đến 10 hay không.
    
     // @param diem chuỗi cần kiểm tra
     //@return true nếu chuỗi không rỗng và đại diện cho một số thực nằm trong khoảng từ 0 đến 10 (bao gồm 0 và 10)
    static boolean validateDiem(String diem) {
        if (diem.length() == 0) return false;
        double d = Double.parseDouble(diem);
        return 0 <= d && d <= 10;
    }
}
